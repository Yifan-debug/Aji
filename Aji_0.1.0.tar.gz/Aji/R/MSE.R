#' Title MSE
#'
#' @param predict
#' @param observe
#'
#' @return
#' @export
#'
#' @examples
MSE2 <- function(predict, observe){
  mean((predict-observe)^2)
}
